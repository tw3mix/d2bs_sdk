Font Mod by thanosdk

1.If you use the font with D2se
Extract the data folder into the mod folder you want to use it with.
Done


2. If you use the Median XL Launcher:
Extract the data folder in the the game's main folder
Find the settings.json file in the Median XL folder, open it using the notepad and change:  

"direct": "false", to "direct": "true",

Save and close, done. 
(credits for this one to szumigajowy).
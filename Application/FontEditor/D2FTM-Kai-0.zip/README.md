# Modern Font Customize solution for Diablo II

*Presented by EAirPeter (dev) & Cai_Miao (design)*

## D2MFC - tool for Diablo II Modern Font Creation

Have you worried about a set of workflow which is complicated to making a shiny new font for your mod project?

Did you ever try to localize D2 in your language but at last gave up when you find you need a extended font to support your language?

This is the **salvation**.

*Note: D2FTM-Kai is the develop code for D2MFC, as it was developed after the D2FTM.*

*Note: D2MFC is planned to be eventually open-sourced*

### Feature

- Generate dc6/tbl pairs of a font with only 1 command line!
- Freetype based, with proper ascent/descent/bearing/advance handling

### Usage
```
D2FTM-Kai.exe <FirstCodePoint> <LastCodePoint> <FontFacePath> <PointSize> <Palette>.dat <Out>.dc6 <Out>.tbl
Construct DC6 and TBL file using the specified font face and point size.
Note: The font must be supported by FreeType.
Use null as the palatte to encode as grayscale images.
```

sample command:
```
.\D2FTM-Kai.exe 0 254 "C:\Windows\font\consola.ttf" 14 act1-fechar.dat font16.dc6 font16.tbl 2> nul
```

`CodePoint`: refers to the Unicode codepoint in decimal, use [the Unicode table](https://unicode-table.com/) wisely

`FontFacePath`: path to a font file. Can't just define a font family name at this time (probably never)

`PointSize`: actually glyph width in pixel, height will be automatically determined

`Palette`: a .dat pallete for color quantization. Currently we provide a modified palette, `act1-fechar.dat`, for you to use, covering 99% conditions (might be, i'm not responsible for the estimating)

`Out`: you know what

`2> nul`: You might need this to supress massive warning echoes, believe me

### Known issue

-  Can't determine the color for now, it's fixed #000 for bg and #FFF for glyph.

- You might encounter `Freetype call failed: FT_Load_Char` error when you generate font, it's because one or more codepoints in the range does not being assigned in the font. You can try `126` as `LastCodePoint` when you generate fonts for basic alphabets only.

- Only one codepoint range can be specify for now, so you might unable to generate through glyphs of your language or generating huge amount of redundant glyphs you will never use.

- Leading (a.k.a. line spacing) is likely to be too high. Use D2FTM to manually patch this.


---

## D2FTM - Diablo II Font Table Master

This is a side project before D2FTM was born, it is developed to fiddle the tbl for fonts, without wasting time on your hex editor, and giving a bit more advanced function to it.

### Feature

- Converts from TBL file to TXT file or vice versa. (The direction of the conversion is determined by the extension of the input file)
- escaping characters for `\t`, `\n` and `\r`
- Values in a character entry can use another char's value, referring with `#<char>` in TXT when compiling TBL.

### Usage

```
 Diablo II Font Table Master
    by EAirPeter, CaiMiao

Usage: .\D2FTM.exe <Input>.tbl <Output>.txt
       .\D2FTM.exe <Input>.txt <Output>.tbl
       .\D2FTM.exe <Input>.tbl
       .\D2FTM.exe <Input>.txt

Convert from TBL file to TXT file or vice versa. (The direction of the conversion is determined by the extension of the input file)
```
Due to the command, you can just drag&drop tbl/txt on the exe to convert.

### Valid txt structure

*generally this is a tab-seperated csv*
```
Woo!	<the nLocale>	<TocalChar>	<Leading>	<CapHeight>
<char>	<width>	<height>	<the bTrue>	<Dc6ImageIndex>
<char>	<width>	<height>	<the bTrue>	<Dc6ImageIndex>
<char>	#<refChar>	#<refChar>	#<refChar>	#<refChar>
...

```

`Woo!`: old magic string

`TocalChar`: total characters in the font, it's automatically set to correct value if you have more or less amount of character entries so it's actually FYI purpose

`Leading`: You may always need to adjust this if you use D2MFC. Note that this is not the final value. See below to calculate final leading

`CapHeight`: *the Font table standard ™* claims it is. Modify this if you want to see what's happening.

`Dc6ImageIndex`: mainly FYI when looking for corresponding glyph in dc6 creator, but you can also modify this

*and so forth, lazy to reprint, you can also refer [the Font table standard ™](https://d2mods.info/forum/viewtopic.php?f=6&t=42044).*

`#<refChar>`: see below for the advanced referencing

### The leading formula

*credits to Necrolis*

`(font height constant of your target language * tbl leading) / 10`

The constant for Latin language should be `17`, others can see the table below.

```
DEFAULT (Latin)  = 17
English (ENG,0x00)  = 17

Japanese (JPN,0x06)  = 15
KOREAN (KOR,0x07)  = 17
Singporean Simplified Chinese (SIN,0x08) = 14
Traditional Chinese (CHI,0x09) = 14
Polish (POL, 0x0a) = 13
Russian (Rus, 0x0b )= 17
```

## the adcanved referencing
```
Woo!	0	65535	14	14
 	4	4	0	0032
!	4	15	0	0033
"	5	14	0	0034
#	11	14	0	0035
a	#!	#!	0	#!
Z	#!	#!	0	#!
```

If you do like this, `a` and `Z` in game will show an exactly `!`

## Warning/Known Issue

- Latin fonts are restricted to 0000-00FF unicode block and 255 chars max. Any char goes beyond that won't load by game, if you want to go through 0100-FFFF then use non-Latin language

- You should have your entries in strict Unicode order, otherwise chars of scrambled part and forth won't load by game

- you can only refer char entries before current char

